#!/bin/bash

name=$(basename "$0")
stock_name="template_task.sh"
if [ $name = $stock_name ]; then
echo "я бригадир, сам не работаю"
exit 1
fi

log="${HOME}/report_${name%.*}.log"
echo "$$ $(date '+%F %T') Скрипт запущен" >> $log

sleep_time=$[30 + RANDOM % (1800 - 30)]
mins=$[sleep_time / 60]
sleep $sleep_time

echo "$$ $(date '+%F %T') Скрипт завершился, работал $mins минут" >> $log

