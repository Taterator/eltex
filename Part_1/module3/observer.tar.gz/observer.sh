#!/bin/bash

list="observer.conf"
log="observer.log"

if [ ! -f $list ]; then
	echo "List not found"
	exit 1
fi

function get_name() {
	while read -r data; do
		ps -p $data | sed -n 2p | awk '{print $4}'
	done
}

function get_proc_names() {
	for pid in /proc/[0-9]*; do
		if [ -f "$pid/cmdline" ]; then
			echo "$pid" | awk -F '/' '{print $3}' | get_name 2> /dev/null
		fi
	done
}

names=$(get_proc_names)

while IFS= read -r line; do
	out=$(echo "$names" | grep -x $line)
	if [[ ! $out ]]; then
		echo "$(date '+%F %T') rebooted $line" >> $log
		nohup bash "$line" &
	fi
done < $list

